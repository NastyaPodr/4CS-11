export * from './user.dto';
export * from './login.dto';
export * from './order.dto';

import { Module, NestModule, MiddlewareConsumer } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserModule } from './user/user.module';
import { OrderModule } from './order/order.module';
import { DbService } from './db.service';
import { AuthorizationMiddleware } from './middlewares/authorization.middleware';

@Module({
  imports: [UserModule, OrderModule],
  controllers: [AppController],
  providers: [AppService, DbService],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(AuthorizationMiddleware)
      .forRoutes('orders');
  }
}